<?php 

require_once('Application.php');
//header("Content-type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
$data = "";
if(isset($_POST) )
{



    $app = new application;

    $result = "";
    $posts = file_get_contents('php://input');
    $jsonData = json_decode($posts, true);
    $uri = $jsonData["uri"];
    $dilimler = explode(",", $uri);

    $imgType = "";
    if(strpos($dilimler[0],"png") != false)
    {
        $imgType = "png";
    } else if(strpos($dilimler[0],"jpeg")){
        $imgType = "jpeg";
    } else {
        $imgType = "jpg";
    }

    $base64_code = ($dilimler[1] != null)? $dilimler[1] : "";
    $uniqName = uniqid();
    if($base64_code != "") {
    $fp = fopen("normalImages/".$uniqName.".".$jsonData["type"], "w+");
    fwrite($fp, base64_decode($base64_code));
    fclose($fp);
        $imagePath = $app->GetBaseUrl()."/normalImages/".$uniqName.".".$jsonData["type"];
        $result = $app->ObjectDetection($imagePath,$imgType);
        $data = json_decode($result);
    }
}



if(!empty($data))
{
    header("Content-type: application/json");
    echo $result;
} else {

    $noData =Array(
        "status" => 500,
        "error"  => "Api not request"
    );
    $noData = json_encode($noData);
    echo $noData;
}


?>