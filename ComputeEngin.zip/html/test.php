<?php 
phpinfo();
echo __DIR__;
?>
